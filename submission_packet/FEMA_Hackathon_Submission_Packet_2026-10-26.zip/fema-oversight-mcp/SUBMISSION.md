# FEMA Evidence & Oversight Graph

**Dataset Access track | Phebe Arouni | October 26, 2026**

A five-tool MCP server that turns public FEMA Public Assistance project records into review indicators with source records, calculation methods, and explicit limits for a human analyst.

## Start Here

1. Read [the judge brief](docs/JUDGE_BRIEF.md).
2. Open [the presentation](presentation/FEMA_Evidence_Oversight_Graph.pptx).
3. Inspect [evaluation documentation](eval/evaluation_documentation.md) and its raw evidence.
4. Reproduce the scenarios using [the reviewer walkthrough](docs/REVIEWER_WALKTHROUGH.md).
5. Review [security](SECURITY.md) and [known limitations](docs/LIMITATIONS_AND_ROADMAP.md).

## Submission Links

| Item | Location |
|---|---|
| Repository recorded in workspace Git configuration | https://github.com/phebeong/2026-HACKATHON |
| Databricks prototype | https://2026h-7474654188777746.aws.databricksapps.com |
| MCP endpoint | https://2026h-7474654188777746.aws.databricksapps.com/mcp |
| Saved validation job | https://dbc-aae0ba16-8727.cloud.databricks.com/jobs/67919837469456?o=7474654188777746 |
| MLflow reference run | https://dbc-aae0ba16-8727.cloud.databricks.com/ml/experiments/1305734463288268/runs/25a3e180b6ea446c984d615a502dde46?o=7474654188777746 |

Databricks links require workspace access. Latest GitHub publication and reviewer access remain final submission checks; workspace edits are not automatically GitHub commits.

## Measured Results

Reference run: `20261026T064618Z`, inside Databricks on Python 3.12.3. Source SHA-256: `c7dd2d9473d8f57f47fb8af0d3207fbfed8183f9f205a6f28e43e393e1731f8f`.

| Check | Observed result | Interpretation |
|---|---|---|
| Automated tests | 52 passed, 0 failed | Validation, security boundaries, registration, identity, rules and browser routes |
| Code lint | Pass | `ruff.log` |
| Detection/control comparisons | 3/3 exact matches | Registered MCP tools replayed over saved inputs; independent SQLite controls |
| Expected first tool selected | 15/15 questions | Small explicit question set, not general accuracy |
| Agent workflows completed | 3/3 | Completion, not narrative correctness |
| Median detection latency | 0.350 / 0.401 / 0.362 seconds | Three calls/tool, in-process MCP with live retrieval |

The cost-share, repeat and category cases used 238, 3,956 and 179 input records. They returned 238 threshold flags, zero repeated groups and three category outliers. The valid zero result is preserved.

## Implemented Scope

FastMCP runs on an authenticated Databricks App. Three deterministic screening tools are paired with two explanation/evidence tools, a provenance resource and a review prompt. Project evidence uses disaster/applicant/worksheet identity. Repeat groups include disaster identity. Responses disclose retrieval caps. A saved job archives tests, inputs, SQL controls and genuine model traces in Databricks and MLflow.

The browser review interface has route tests; its production model access is not certified by the notebook evaluation. The tools retrieve OpenFEMA directly. They do not execute calculations through Unity Catalog functions or the adjacent Genie space.

## Limits That Matter

This is a review prototype, not a fraud detector, eligibility engine, official financial report, Section 406/CEF validator, or payments workflow. It does not verify declaration-specific authorized shares or fully match peer projects by scale and geography.

A sampled model answer added unsupported legal citations and misstated a ratio boundary. [The narrative review](eval/NARRATIVE_QUALITY_REVIEW.md) preserves that finding about output quality. No zero-hallucination, retrieval-accuracy, citation-coverage or audit-savings claim is made.

## Packet Status

Included: revised deck, evaluation in Markdown/Word, a PDF judge brief, design and security documents, reviewer instructions, rubric map, Q&A, submission copy, and raw evidence. Recording is excluded at the user's request. Nothing has been submitted to the organizers by this task.
