# Presenter Notes

Core story: slides 1-15. Slides 16-20 are reviewer appendix material. Recording is excluded.

## Slide 1: FEMA Evidence & Oversight Graph
Public data can answer what was funded. This prototype helps an analyst ask what deserves review and why. It combines five MCP tools with traceable calculations and evidence. It is a read-only sandbox, not a finding or eligibility engine.

## Slide 2: A funding total is not enough.
The analyst needs a calculation they can inspect, a source record they can identify, and limits they can explain. We do not claim a measured labor saving; we address a reviewability gap.

## Slide 3: Five actions built around analyst work.
Three tools screen records. Two explain the rule and package evidence. Their names and schemas express analyst goals rather than exposing an unrestricted API or SQL executor.

## Slide 4: Hosted on Databricks. Backed by OpenFEMA.
The actual submission is API-backed FastMCP on Databricks Apps. The loaded table and Genie space are adjacent assets, not this measured calculation path. The graph is a directed review workflow implemented by a bounded tool loop.

## Slide 5: Context lives in the tool contract.
Worksheet numbers alone are not globally unique. We reject ambiguous evidence identities and include disaster in repeated grouping. Category filtering improves relevance, but it is not matched engineering-cost analysis. Cost-share authority remains unverified.

## Slide 6: Three Category C outliers. Same SQL identities.
For Florida disaster 4673, the snapshot had 179 Category C records. The tool and independent SQL control returned the same three project identities. The bars show actual project amounts, not an allegation of excess or improper cost.

## Slide 7: 238 flags are not 238 proven problems.
All 238 eligible records in this cost-share test exceeded the configured upper band. That is the calculation result. The screen does not determine whether a declaration authorized the share. It demonstrates why domain context must accompany a threshold.

## Slide 8: Preserve the project identity and the limits.
The real brief for worksheet 169 uses disaster 4734 and applicant 123-0BE2A-00. It packages source fields and method. It explicitly does not independently verify the indicator trigger, and the analyst must review policy context.

## Slide 9: The same inputs. Two independent calculations.
We save the source snapshot once, replay it through the actual registered MCP tool, and compute a separate SQLite control. This avoids a moving-source comparison and tests the implementation rather than copied tool logic. Live calls and model traces are separate layers.

## Slide 10: Evidence, not target percentages.
These are narrow measured results from the selected reference run. The 15-question routing set is explicit and developer-authored. Three workflows completed, but that is not a claim that every sentence is correct. There is no general retrieval or hallucination score.

## Slide 11: Live retrieval and calculation: 0.35-0.40s medians.
Each median uses three real calls inside Databricks with live OpenFEMA access. It excludes remote MCP transport, model time and browser rendering. Three samples are not a load benchmark or service-level commitment.

## Slide 12: Constrain access. Preserve reviewability.
The tools have no write or payment action. Fixed-origin outbound access and sanitized errors address specific boundaries, with tests. Databricks authentication protects the app. Human review and narrative grounding are not solved by tool annotations or a system prompt.

## Slide 13: A correct tool can still get an unreliable explanation.
We inspected actual model answers. One introduced statutory citations that were not in its tool evidence, called a section Key Finding, and said 90 percent was outside a 70 to 95 percent band. Those issues are retained in the raw trace. This is why completion is not correctness.

## Slide 14: Make the analyst question reviewable.
The contribution is a reusable evidence contract. It can help an analyst inspect public funding without treating a screen as a verdict. We have not measured audit savings or improper-payment reduction, and we do not claim another agency integration is already built.

## Slide 15: Grounding first. Then scale and comparability.
Before operational reliance, add authorized-share rules, full source pagination, matched cohorts and claim-level verification. Expand independent and adversarial testing, then benchmark remote transport and review permissions. Financial execution remains outside this project.

## Slide 16: Three questions a judge can reproduce.
Use these as live demonstration prompts, not as additional held-out test results. If repeated groups are zero, keep the zero. Do not stage a comparison or invent a positive record. Recording is excluded from this packet.

## Slide 17: A test run should leave enough evidence to challenge it.
The reference folder contains raw inputs and outputs, not just a scorecard. The source hash matches the evaluated code. A fresh run creates a new dated folder. Live records may change, so the comparison must use the same saved snapshot.

## Slide 18: What this prototype does not claim.
This slide makes the boundaries explicit. There is no policy eligibility engine, fraud finding, payment path or production compliance claim. The graph describes the review flow; the implementation is a bounded tool loop. Keep these distinctions in Q and A.

## Slide 19: Run the saved Databricks validation job.
Reviewers need approved workspace access. Start at SUBMISSION.md and the saved job. GitHub synchronization and reviewer permissions are final administrative checks. This documentation task does not submit anything to the organizers.

## Slide 20: Primary sources and inspectable project evidence.
The revised story avoids unsupported legal metrics and executive-order assertions. External references establish event, data and platform context; the project artifacts establish measured results. See SOURCES.md for the claim register.
