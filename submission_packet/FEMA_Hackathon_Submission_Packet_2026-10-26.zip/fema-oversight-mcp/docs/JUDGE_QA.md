# Judge Questions and Direct Answers

## What differs from an API wrapper?

The server adds bounded analyst tasks, calculations, identity checks, validation, source limits and review language. The method and evidence tools make the screening output inspectable. It does not claim a new statistical algorithm.

## What was measured?

52 tests passed; three detection sets matched SQL controls; 15/15 expected first-tool names were selected; three workflows completed. Detection medians were 0.350, 0.401 and 0.362 seconds, based on three live in-process calls each. None establishes general answer accuracy.

## Did the model hallucinate?

One answer added legal citations absent from evidence and said 90% was outside a 70-95% band. It also used 'Key Finding.' The trace is retained. We do not claim zero unsupported claims or legal correctness.

## Why were all 238 cost-share records flagged?

They exceeded the chosen upper band. Declaration-specific authorization is not checked; legitimate 100% shares can be returned. These are not 238 confirmed problems.

## Why zero repeated groups?

No group in the 3,956-record cohort met the exact same-disaster/applicant/title/category rule. SQL also returned zero. Labeled synthetic tests separately verify positive grouping.

## Is Unity Catalog the backend?

Not for the submitted tool calculations. Tools call OpenFEMA directly. A loaded table and Genie space exist as adjacent assets. Databricks Apps hosts the service and Databricks/MLflow retain evidence.

## What does graph mean?

The directed review workflow. The implementation is a bounded tool loop, not a separate graph framework; human sign-off is procedural.

## Does it find fraud or decide eligibility?

No. It surfaces indicators. It does not validate policy violations, Section 406/CEF eligibility or declaration-specific shares, and cannot move money.

## How do judges reproduce it?

Use the saved notebook/job, inspect the new results and compare tool/control on identical archived inputs. The packet preserves test/lint logs, source snapshots, model calls and hashes. Counts can change with refreshes.

## What comes next?

Claim-level grounding and authorized-share context first, then full source pagination, matched peer cohorts, broader held-out/adversarial evaluation and remote transport/security testing.

## Can judges access the system?

The app is authenticated in the hackathon workspace. Arrange approved access and verify the latest repository files before submission. Documentation upload does not publish GitHub changes.
