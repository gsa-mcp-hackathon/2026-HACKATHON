# Judge Criteria and Evidence Map

The [official GSA page](https://www.gsa.gov/super-intelligence/si-community-of-practice/events-and-training/mcp-server-and-si-agent-government-hackathon) identifies Technical Quality, Innovation, Mission Alignment and Presentation. This is the project's evidence map, not an official score.

| Criterion | Argument | Evidence | Qualification |
|---|---|---|---|
| Technical quality | Separate models, retrieval and tool modules; validation/error boundaries | Source, 52-case JUnit report, lint log | Not formal certification or penetration testing |
| Reliability | Same-input independent controls and retained failures | Snapshots, SQL comparisons, logs, hashes | Limited cohorts; no load/availability benchmark |
| Agent-facing design | Tools express analyst actions | Five schemas; 15-question first-tool set; method/evidence tools | Small explicit question set |
| Innovation | Pair screening with explanation and disaster-aware identity | Briefs, grouping, provenance and real traces | No novel-statistics or full-policy-engine claim |
| Mission alignment | Reviewable public disaster-funding analysis | Worked example and explicit limits | Savings and payment-integrity benefits are intended, not measured |
| Presentation | A reproducible story with honest boundaries | Deck, brief, walkthrough, Q&A and evaluation | Recording excluded |

The strongest evidence is the path from question to tool, calculation and records. The weakest area is model narrative grounding, documented rather than presented as solved.
