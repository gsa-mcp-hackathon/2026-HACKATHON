# FEMA Evidence & Oversight Graph

**Dataset Access track | Phebe Arouni | October 29, 2026 | Updated November 2, 2026 (app page redesign and repeat rule)**

A five-tool MCP server that turns public FEMA Public Assistance project records into review indicators with source records, calculation methods, and explicit limits for a human analyst.

## Start Here

1. Read [the judge brief](docs/JUDGE_BRIEF.md).
2. Open [the presentation](presentation/FEMA_Evidence_Oversight_Graph.pptx).
3. Inspect [evaluation documentation](eval/evaluation_documentation.md) and its raw evidence.
4. Reproduce the scenarios using [the reviewer walkthrough](docs/REVIEWER_WALKTHROUGH.md).
5. Review [security](SECURITY.md) and [known limitations](docs/LIMITATIONS_AND_ROADMAP.md).

## Submission Links

| Item | Location |
|---|---|
| Published repository | https://github.com/phebeong/2026-HACKATHON |
| Databricks prototype | https://2026h-7474654188777746.aws.databricksapps.com |
| MCP endpoint | https://2026h-7474654188777746.aws.databricksapps.com/mcp |
| Saved validation job | https://dbc-aae0ba16-8727.cloud.databricks.com/jobs/67919837469456?o=7474654188777746 |
| MLflow reference run | November 2: https://dbc-aae0ba16-8727.cloud.databricks.com/ml/experiments/1305734463288268/runs/ff6c41f62dc04e2c929fea1e08ba3e21?o=7474654188777746 ; October 29: https://dbc-aae0ba16-8727.cloud.databricks.com/ml/experiments/1305734463288268/runs/7445e452abfc4cd89896658d4ab7f44a?o=7474654188777746 |

Databricks links require workspace access. GitHub publication status is recorded in docs/SUBMISSION_CHECKLIST.md. Databricks reviewer access must follow the approved organizer process.

## Measured Results

Reference run: `20261102T152007Z` (November 2, current rule), inside Databricks on Python 3.12.3. Source SHA-256: `9cdad51ec7870e12d2fff37a2b570a5030835a5b799f542b8560f6224990ea94`. The October 29 run `20261029T111811Z` (SHA-256 `f70d0a80f54a3e69113fca8755d305828d87263db9e882089b879c5307cd645c`) is retained for the earlier exact-title rule.

| Check | Observed result | Interpretation |
|---|---|---|
| Automated tests | 64 passed, 0 failed | Validation, security boundaries, registration, identity, rules and browser routes |
| Code lint | Pass | `ruff.log` |
| Detection/control comparisons | 3/3 exact matches | Registered MCP tools replayed over saved inputs; independent SQLite controls |
| Expected first tool selected | 15/15 questions | Small explicit question set, not general accuracy |
| Agent workflows completed | 3/3 | Completion, not narrative correctness |
| Median detection latency | 0.339 / 0.380 / 0.340 seconds | Three calls/tool, in-process MCP with live retrieval |

The cost-share, repeat and category cases used 238, 3,964 and 179 input records. They returned 238 threshold flags, 74 repeated-title groups (195 worksheets) and three category outliers, each matching its SQLite control. Under the October 29 exact-title rule the same repeat cohort (3,962 records then) returned zero groups; that result is preserved in the October 29 run.

## Implemented Scope

FastMCP runs on an authenticated Databricks App. Three deterministic screening tools are paired with two explanation/evidence tools, a provenance resource and a review prompt. Project evidence uses disaster/applicant/worksheet identity. Repeat groups include disaster identity. Responses disclose retrieval caps. A saved job archives tests, inputs, SQL controls and genuine model traces in Databricks and MLflow.

On October 29 the hosted browser cost-share scenario completed successfully in a separate observed smoke test. Authenticated health and a remote MCP methodology call also passed; this is not a load or availability benchmark. The tools retrieve OpenFEMA directly. They do not execute calculations through Unity Catalog functions or the adjacent Genie space.

## November 2, 2026 Update

The app's web page (`src/fema_oversight/analyst.html`) was redesigned for non-technical reviewers: a plain-English introduction, three clickable question cards (road and bridge repair costs for Hurricane Ian, Florida disaster 4673; utility repair costs for Hurricane Ida, Louisiana disaster 4611, with an evidence packet for the top project; and repeated project titles for disaster 4673), a four-step progress indicator based on real browser states, summary tiles that keep records checked, flagged for review, examples shown and download completeness separate, charts drawn only from the returned results, and expandable technical detail with the raw records. The cost-share tool is still part of the server and the evaluation; it no longer has a card on the page.

The repeated-worksheet rule changed: titles are now compared after ignoring capitals, punctuation and standalone numbers, so "Naples Access to Beach - 1" and "Naples Access to Beach - 2" match. FEMA titles are almost never repeated exactly; the October 29 exact-title rule found no groups in 10 Florida disasters or a 140,000-record national sample. Numbered series are often legitimate (separate buildings, sites or phases).

New recorded run `20261102T152007Z` (Databricks, Python 3.12.3; MLflow run `ff6c41f62dc04e2c929fea1e08ba3e21`; source SHA-256 `9cdad51ec7870e12d2fff37a2b570a5030835a5b799f542b8560f6224990ea94`): 71/71 tests and lint pass; all three SQLite controls match (238 cost-share flags for disaster 4734; 74 repeated-title groups covering 195 of 3,964 worksheets for disaster 4673; 3 of 179 Category C outliers for disaster 4673); the model selected the expected first tool on 15/15 questions; 3/3 model workflows and 3/3 grounded review workflows passed; on the exact-count comparison tools matched 15/15 and the model without tools matched 0/15 (abstained 15/15). The repeat SQLite control computes the title pattern with its own character-by-character function, not the tool's code.

Live app check on November 2 (same code in-process, live OpenFEMA data): road and bridge 3 of 179 flagged, the largest about 25 times the average; utilities 3 of 115 flagged, the largest (Houma Power Plant, worksheet 1725) about 31 times the $4.80M average, matching a direct SQLite control; listed twice 74 groups in 3,964 records. The October 29 run (`20261029T111811Z`, SHA-256 `f70d0a80...`) is kept for the earlier exact-title rule. The hosted-app smoke test was not re-recorded: the app's sign-in redirect could not be completed from the evaluation notebook. See `docs/NOVEMBER_2_UPDATE.md`.

## Limits That Matter

This is a review prototype, not a fraud detector, eligibility engine, official financial report, Section 406/CEF validator, or payments workflow. It does not verify declaration-specific authorized shares or fully match peer projects by scale and geography.

An October 26 model answer added unsupported legal citations and misstated a ratio boundary. The October 29 browser now renders its displayed summary from structured tool evidence. Three real model-to-tool review workflows passed the new check. Tool and filter selection still require human review. [The narrative review](eval/NARRATIVE_QUALITY_REVIEW.md) preserves that finding about output quality. No zero-hallucination, retrieval-accuracy, citation-coverage or audit-savings claim is made.

## Comparison Baseline

On three archived exact-count questions repeated five times, registered tools matched the independent controls in 15/15 trials. The same model without source records or tools returned no exact counts and abstained in all 15 trials. This is a narrow data-access comparison, not general answer accuracy or a statistically independent sample. Raw responses: `eval/results/20261102T152007Z/baseline_count_comparison.json` (October 29: same 15/15 vs 0/15 in `eval/results/20261029T111811Z/`).

## Packet Status

Included: revised deck (updated November 2 for the new page), evaluation in Markdown/Word, an editable judge brief, design and security documents, reviewer instructions, rubric map, Q&A, submission copy, and raw evidence. A captioned evidence walkthrough (rebuilt November 2 from the updated deck) accompanies the deck; see the recording status in presentation/RECORDING_KIT.md. Nothing has been submitted to the organizers by this task.

## Verified Publication

The reviewed source and packet were published in commit [f21fe97](https://github.com/phebeong/2026-HACKATHON/commit/f21fe978c49d45fdfd66aa39683b5d7ad92cda84). That tree matches the October 29 release (Python source SHA-256 f70d0a80f54a3e69113fca8755d305828d87263db9e882089b879c5307cd645c). The November 2 page and repeat-rule changes (SHA-256 9cdad51ec7870e12d2fff37a2b570a5030835a5b799f542b8560f6224990ea94) are not part of commit f21fe97. Final organizer submission remains pending.
