# Evidence walkthrough and live demo

The captioned walkthrough (first made October 29, rebuilt November 2, 2026 from the updated deck) is assembled from the deck and recorded project evidence. It is not a continuous live screen recording and has no spoken audio. The hosted demo is separately tested. Do not describe a plain model as having attempted web search: the baseline had no source tools or records and abstained.

## Suggested spoken demo

Open the hosted app. The page opens with three short boxes: the problem, what the app checks and why the evidence matters. Click **Are any road and bridge projects unusually expensive?** for Florida disaster 4673. While the four progress steps run, explain that the model chooses the checks and the tools pull live OpenFEMA records. Point out the headline and the four tiles: 179 records checked, 3 flagged, 3 shown and a complete download, and the chart against the group average. The independent SQL calculation matched those project identities on the same 179 input records.

Click **Are any utility repairs unusually expensive?** for Louisiana disaster 4611. Show 3 of 115 flagged and open the evidence packet for worksheet 1725, the Houma Power Plant. Explain that a large repair can be legitimate.

Click **Is the same project listed more than once?** Show 74 groups in 3,964 records and open the matching titles, for example "Naples Access to Beach - 1" to "- 7". Explain that titles are compared after ignoring capitals, punctuation and numbers, and that numbered series are often legitimate. Open **For reviewers and technical judges** to show the executed settings, raw records and raw response, then use **Download evidence (JSON)**.

Close by showing the saved validation evidence: 71 tests, three independent SQL comparisons and 15/15 first-tool selections. Explain the observed prose failure and the implemented evidence renderer. The analyst still checks filters, records and program context.

## Recording limits

Use only actual output. Do not claim Unity Catalog calculations, a signed human approval gate, fraud detection, measured savings, general answer accuracy, or browser performance based on notebook timings. If a continuous narrated demo is required by a private organizer instruction, record it against the tested authenticated app before final submission.
