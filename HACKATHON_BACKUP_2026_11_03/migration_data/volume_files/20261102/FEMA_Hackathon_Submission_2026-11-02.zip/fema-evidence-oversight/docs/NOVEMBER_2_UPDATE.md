# November 2, 2026 Update

## What changed

* **App page.** Redesigned for non-technical reviewers: plain-English introduction, three question cards, four-step progress based on real browser states, summary tiles (records checked, flagged for review, examples shown, download completeness), charts drawn from the returned results, and expandable raw evidence. The cards are:
  * Are any road and bridge projects unusually expensive? (Florida disaster 4673, Hurricane Ian, Category C)
  * Are any utility repairs unusually expensive? (Louisiana disaster 4611, Hurricane Ida, Category F, with an evidence packet for the top project)
  * Is the same project listed more than once? (Florida disaster 4673)
  The cost-share tool remains in the server, tests, evaluation and notebook; it no longer has a card.
* **Repeated-worksheet rule.** Titles are compared after lowercasing, replacing punctuation with spaces and dropping standalone numbers. Groups are formed by disaster, applicant, title pattern and damage category; empty patterns are skipped. Each group now returns `title_pattern`, `application_titles`, `distinct_title_count` and `damage_category_code`.
* **Data caveat wording.** Shortened to "Figures are from FEMA's Grants Manager, not FEMA's official financial system. Not for official reporting." in the tool outputs and on the app page.
* **Project names on the cost chart.** `detect_category_outliers` now also returns each flagged project's `application_title`; the app shows it under the project number. Which projects are flagged, and how many, is unchanged.

## Why the rule changed

FEMA project titles are almost never repeated exactly. Before the change, the exact-title rule returned zero groups for Florida disasters 4673, 4734, 4680, 4709, 4806, 4828, 4834, 4399, 4564, 4468 and 4337, and in a 140,000-record national sample (1,737 disasters; OpenFEMA rate limits prevented a full 851,349-record download). The new rule finds numbered series such as "Naples Access to Beach - 1" to "- 7". Many are legitimate (separate buildings, sites or phases); a group is a reason to compare worksheets, not a finding.

## Evidence (recorded run `20261102T152007Z`)

| Check | Result |
|---|---|
| Source SHA-256 | `9cdad51ec7870e12d2fff37a2b570a5030835a5b799f542b8560f6224990ea94` |
| Automated tests / lint | 71/71 / clean (two new repeat tests, six title-pattern cases) |
| SQLite controls (same inputs) | cost share 238 = 238; repeats 74 = 74 (195 of 3,964 worksheets); category 3 = 3 |
| Repeat control independence | Title pattern re-implemented character by character, no regular expressions |
| Additional live controls (run separately on November 2, not part of the recorded run) | Florida 4834: 38 = 38; Florida 4734: 37 = 37; Louisiana 4611 Category F outliers: 3 = 3 |
| First-tool selection | 15/15 |
| Model workflows / grounded review workflows | 3/3 / 3/3 |
| Exact counts, tools vs no tools | 15/15 vs 0/15 (15 abstentions) |
| MLflow | experiment `1305734463288268`, run `ff6c41f62dc04e2c929fea1e08ba3e21` |

`eval/baseline_lift.py` now reads the run from `FEMA_EVIDENCE_RUN` (default `20261102T152007Z`) and an optional `FEMA_DATABRICKS_PROFILE`. The hosted-app smoke test (`eval/hosted_smoke.py`) was not re-recorded: from the evaluation notebook the app answered with a sign-in redirect (HTTP 302). The October 29 hosted smoke record remains in `eval/results/20261029T111811Z/`.

## What is unchanged

The October 29 run `eval/results/20261029T111811Z/` (SHA-256 `f70d0a80f54a3e69113fca8755d305828d87263db9e882089b879c5307cd645c`) is kept and describes the October 29 code, with one exception: the data caveat sentence was later shortened in its saved outputs and in the October 29 source copy (that source copy now fingerprints as `ad4d17156ead50b0d9633e91360634768df1ba95a56b4c4c5c24a87417b062ab`; the October 29 run itself recorded `f70d0a80f54a3e69113fca8755d305828d87263db9e882089b879c5307cd645c`). The cost-share, explanation and evidence-brief tools, the model loop and the evidence-summary renderer did not change; the category-outlier tool only gained a project-name field.
