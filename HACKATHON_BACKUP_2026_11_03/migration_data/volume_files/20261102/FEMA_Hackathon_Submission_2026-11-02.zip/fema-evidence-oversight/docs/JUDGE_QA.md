# Judge Questions and Direct Answers

## What differs from an API wrapper?

The server adds bounded analyst tasks, calculations, identity checks, validation, source limits and review language. The method and evidence tools make the screening output inspectable. It does not claim a new statistical algorithm.

## What was measured?

On November 2, 71 tests passed; three detection sets matched SQL controls; 15/15 expected first-tool names were selected; three workflows completed. Detection medians were 0.364, 0.456 and 0.375 seconds (October 29: 64 tests; 0.339, 0.380 and 0.340 seconds), based on three live in-process calls each. None establishes general answer accuracy.

## Did the model hallucinate?

One answer added legal citations absent from evidence and said 90% was outside a 70-95% band. It also used 'Key Finding.' The October 26 trace is retained. The October 29 browser renders its summary from structured tool evidence, with targeted regression tests and three successful workflows. Tool selection and filters still need review; no general correctness claim is made.

## Why were all 238 cost-share records flagged?

They exceeded the chosen upper band. Declaration-specific authorization is not checked; legitimate 100% shares can be returned. These are not 238 confirmed problems.

## Why did repeated groups change from zero to 74?

On October 29 no group in the 3,962-record cohort met the exact same-disaster/applicant/title/category rule; SQL also returned zero. FEMA titles are almost never repeated exactly, so on November 2 the rule was changed to compare titles after ignoring capitals, punctuation and standalone numbers. It returns 74 groups (195 worksheets) in the 3,964-record cohort, matched by an independent SQL control. Many are numbered series such as separate buildings or sites, which are often legitimate.

## Is Unity Catalog the backend?

Not for the submitted tool calculations. Tools call OpenFEMA directly. A loaded table and Genie space exist as adjacent assets. Databricks Apps hosts the service and Databricks/MLflow retain evidence.

## What does graph mean?

The directed review workflow. The implementation is a bounded tool loop, not a separate graph framework; human sign-off is procedural.

## Does it find fraud or decide eligibility?

No. It surfaces indicators. It does not validate policy violations, Section 406/CEF eligibility or declaration-specific shares, and cannot move money.

## How do judges reproduce it?

Use the saved notebook/job, inspect the new results and compare tool/control on identical archived inputs. The packet preserves test/lint logs, source snapshots, model calls and hashes. Counts can change with refreshes.

## What comes next?

Authorized-share context, filter accuracy, complete source pagination, matched peer cohorts and broader independent evaluation. A remote MCP smoke test passed; load and independent security testing remain future work.

## Can judges access the system?

The app is authenticated in the hackathon workspace. Arrange approved access and verify the latest repository files before submission. Documentation upload does not publish GitHub changes.
